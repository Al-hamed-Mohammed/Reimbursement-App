﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManager2.Models
{
    public enum Dept
    {
        None,
        HR,
        IT,
        Payroll,
        Services
    }
}
